﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO; //pliki
using System.Text; // kodowanie

public partial class SaveFile : System.Web.UI.Page
{
    string PATH = HttpContext.Current.Server.MapPath("pliki/text.txt");
    protected void Page_Load(object sender, EventArgs e)
    {
        //string k = Request["k"];
        //string xs = Request["xs"];
        //string fullDate = Request["fullDate"];
        string moja = Request["moja"];

        if (moja != null )
        {
        Save(moja);
        Response.Write("Dane zapisane");
        }
        else {
        Response.Write("brak danych");
        }
        }


    //zapis pliku
    private void Save(string moja) {
        StreamWriter writer = new StreamWriter(PATH, true, Encoding.UTF8);
        writer.WriteLine(moja);
        writer.Close();
    }
}